cd cluster-configuration/7003 && redis-server redis.conf
