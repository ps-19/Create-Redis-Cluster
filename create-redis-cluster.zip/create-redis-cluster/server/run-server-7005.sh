cd cluster-configuration/7005 && redis-server redis.conf
