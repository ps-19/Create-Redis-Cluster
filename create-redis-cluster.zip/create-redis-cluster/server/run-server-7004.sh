cd cluster-configuration/7004 && redis-server redis.conf
