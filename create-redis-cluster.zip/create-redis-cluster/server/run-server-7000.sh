cd cluster-configuration/7000 && redis-server redis.conf
