cd cluster-configuration/7001 && redis-server redis.conf
