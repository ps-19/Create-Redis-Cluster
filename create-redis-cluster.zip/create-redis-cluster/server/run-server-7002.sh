cd cluster-configuration/7002 && redis-server redis.conf
