## Create Redis Cluster in one go.
Make sure redis is installed.

Installation guide - https://redis.io/download

```shell
# Clone the Repo
$ git clone https://github.com/spiderxm/create-redis-cluster.git
# Move to the folder
$ cd create-redis-cluster
# Execute bash file
$ sh create-redis-cluster.sh
```

Wait for the magic

Boom cluster is up and running

Made by Mrigank anand

For more info on redis cluster refer official [Redis Cluster](https://github.com/spiderxm/Cyclo)